import numpy as np
# basic class:edge(lane),junction,connection
# traffic_light class:tl_Logic,Phase,request
# vehicle class:vehicle,trip,flow
from bintrees import RBTree
MAX_CONNECTION_NUMBER=30
MAX_PAST_VEHICLE_PER_SECOND=5
ACCELERATION=5
MAX_SPEED=10
class flow:
    def __init__(self, id,depart,origin,destination,begin,end,vehsPerHour):
        self.id = id
        self.depart = depart
        self.origin = origin
        self.destination = destination
        # self.origin_index=-1
        # self.destination_index=-1
        self.begin=float(begin)
        self.end=float(end)
        self.vehsPerHour=float(vehsPerHour)
        self.route=None
        self.connection_id_list=[]
        self.display()
    def vehicle_generate(self,current_time):
            return vehicle(self.id+"_"+str(current_time),self.origin,self.route,self.connection_id_list,current_time)
    def connection_generate(self,edges):
        for index,edge_id in enumerate(self.route):
            if index==len(self.route)-1:
                break
            for connection in edges[edge_id].from_connections:
                if connection.to_edge==self.route[index+1]:
                    self.connection_id_list.append(connection.index)
                    break
    def display(self):
        #print("Flow Name:", self.id, ", Depart:", self.depart, ", Origin:", self.origin, ", Destination:", self.destination)
        return
class trip:# 从一个lane的起点到另一个lane的起点(endpoint)
    def __init__(self, id,depart,origin,destination):
        self.id = id
        self.depart = depart
        self.origin = origin
        self.destination = destination
        self.route=None
        self.display()
    def display(self):
        #print("Trip Name:", self.id, ", Depart:", self.depart, ", Origin:", self.origin, ", Destination:", self.destination)
        return
class vehicle:
    def __init__(self, id,position,route,connection_list,depart_time,speed=10):
        self.id = id
        self.speed =float(speed)
        self.position=position #在edges中的id
        self.moving_precent=0 #当前edge上的移动距离
        self.move_rate=-1
        self.route=route # vehicle路径
        self.connection_list=connection_list # vehicle路径上的connection
        self.depart_time=float(depart_time)
        self.wait=False #是否等待
        self.total_waiting_time=0
        self.linkIndex=-1
        self.traffic_light=None
        self.current_connection=None
        self.max_speed=MAX_SPEED
        self.direction=1 #沿着当前lane的方向，1为正，-1为负 (暂时没用)
        self.next_connection_id=None
        self.acceleration=ACCELERATION
        #self.display()
    def __lt__(self, other):
        return self.depart_time < other.depart_time
    def display(self):
        #print("Vehicle Name:", self.id, ", Position:", self.position,
              #"will launch at:",self.depart_time,", Speed:", self.speed,
              #", Direction:", self.direction)
        return
    def move(self,edges,junctions):
        if self.move_rate==-1:
            self.move_rate=self.speed/edges[self.position].length
            # print("Vehicle Name:", self.id, ", Position:", self.position,"move_rate:",self.move_rate)
        if self.wait==False:
            tmp_position=edges[self.position]
            self.moving_precent+=self.move_rate
            # print("Vehicle Name:", self.id, ", Position:", self.position,"moving_precent:",self.moving_precent)
            if self.moving_precent>=1:
                tmp_position_index=self.route.index(self.position)


                ####################################################################3
                if tmp_position_index == len(self.route)-1:
                    next_position_name=self.route[tmp_position_index]
                else:
                    next_position_name=self.route[tmp_position_index+1]
                ####################################################################3

                #next_position_name=self.route[tmp_position_index+1]
                for connection in tmp_position.from_connections:
                    #print(next_position_name ,connection.to_edge)
                    if connection.to_edge==next_position_name:
                        if (connection.via==None or connection.linkIndex==None):#目前路径的最大流量限制对无信号灯的路口无效
                                connection.current_past_count+=1
                                self.position=next_position_name
                                self.moving_precent=0
                                self.move_rate=self.speed/edges[self.position].length
                                break
                                #print("Vehicle Name:", self.id, ", Position:", self.position,"start waiting")
                        else:
                            #print("find connection")
                            # matching_indices = [i for i, x in enumerate(junctions) if x.id == connection.via]
                            self.traffic_light=connection.via
                            self.linkIndex=int(connection.linkIndex)
                            self.current_connection=connection
                            
                            
                            # if connection.via not in junctions:
                            #     continue
                            # if not hasattr(junctions[connection.via].current_phase, 'state'):
                            #     continue  # 如果没有state属性，则跳过                       
                            if junctions[connection.via].current_phase.state[self.linkIndex]=="r" \
                            or junctions[connection.via].current_phase.state[self.linkIndex]=="R"\
                            or connection.current_past_count>=connection.max_past_per_second:
                                self.wait=True
                                connection.waiting_vehicles.append(self)
                                # print("Vehicle Name:", self.id, ", Position:", self.position,"start waiting")
                            else :
                                # matching_indices = [i for i, x in enumerate(edges) if x.id == next_position_name]
                                connection.current_past_count+=1
                                self.position=next_position_name
                                self.moving_precent=0
                                self.move_rate=self.speed/edges[self.position].length
                            break
        else:
            #if not hasattr(junctions[self.traffic_light].current_phase, 'state'):
                #continue
            if junctions[self.traffic_light].current_phase.state[self.linkIndex]==("G" or "g" or "y") and self.current_connection.current_past_count<self.current_connection.max_past_per_second:
                self.current_connection.current_past_count+=1
                tmp_position_index=self.route.index(self.position)
                next_position_name=self.route[tmp_position_index+1]
                self.wait=False
                #self.current_connection.waiting_vehicles.remove(self)

                ########################################################################33
                if self in self.current_connection.waiting_vehicles:
                    self.current_connection.waiting_vehicles.remove(self)
                else:
                    pass  # 或者进行适当的处理
                ########################################################################33

                # matching_indices = [i for i, x in enumerate(edges) if x.id == next_position_name]
                self.position=next_position_name
                self.moving_precent=0
                self.move_rate=self.speed/edges[self.position].length
                # print("Vehicle Name:", self.id, ", Position:", self.position,"end waiting")
        if self.position==self.route[-1]:
            #print("Destination Reached")
            edges[self.position].arrive_count+=1
            return 1
        return 0
class edge:
    def __init__(self, id,length,speed_limit=1e9 ):
        self.id = id
        self.length=length
        self.from_connections=[] # 从这个lane出发的connection
        self.to_connections=[] # 到这个lane的connection
        self.from_edges=[] # 指向这个lane的edge
        self.to_edges=[] # 从这个lane指向的edge
        self.depart_count=0  
        self.arrive_count=0
        self.speed_limit=speed_limit
        self.display()
    def display(self):
        #print("Edge Name:", self.id, ", Length:", self.length, ", Speed Limit:", self.speed_limit)
        return
class connection:
    def __init__(self,from_edge,to_edge,via=None,linkIndex=-1,dir=None,state=None):
        self.from_edge=from_edge
        self.to_edge=to_edge
        self.via=via
        self.index=None
        self.linkIndex=linkIndex
        self.max_past_per_second=MAX_PAST_VEHICLE_PER_SECOND
        self.current_past_count=0
        self.dir=dir
        self.state=state
        self.waiting_vehicles=[]
        self.total_waiting_time=0
        self.display()
    def display(self):
        #print("Connection Name:", self.from_edge, "->", self.to_edge, ", Via:", self.via, ", LinkIndex:", self.linkIndex)
        return
    def waiting_time_calculation(self):
        for vehicle in self.waiting_vehicles:
            vehicle.total_waiting_time+=1
            self.total_waiting_time+=1
class request:# 动态交通信号
    def __init__(self,index,response):
        self.index=index
        self.response=response
        self.display()
    def display(self):
        #print("Request Index:", self.index, ", Response:", self.response)
        return
class junction:
    def __init__(self, id):
        self.id = id
        self.requests=[] # 动态交通信号
        # self.traffic_light=None # 静态交通信号
        self.connections=[None]*MAX_CONNECTION_NUMBER # 相连的lane 
        self.current_phase=None
        self.display()
        self.use_request=-1 #默认交通模式
        self.junction_point_to=[]
        self.junction_point_in=[]
        self.edge_point_to=[]
        self.edge_point_in=[]
    def display(self):
        #print("Junction Name:", self.id)
        return

class Phase:
    def __init__(self, duration, state):
        self.duration =int(duration)
        self.state = state
        self.display()
    def display(self):
        #print("Duration:", self.duration, ", State:", self.state)
        return
class tl_Logic:# 静态交通信号
    def __init__(self,id):
        self.phases = []
        self.id=id
        self.runtime=0
        self.current_phase=None
        self.display()
        self.junctions=[]
    def add_phase(self, duration, state):
        phase = Phase(duration, state)
        self.phases.append(phase)
    def change_phase(self,a):
        #print("len(self.phases)=",len(self.phases))

        if (self.current_phase).duration==self.runtime:
            tmp_phase_index=self.phases.index(self.current_phase)
            self.current_phase=self.phases[(tmp_phase_index+1)%len(self.phases)]
            # self.current_phase=self.phases[a % len(self.phases)]
            self.runtime=0
        else:
            self.runtime+=1
        #print("self.current_phase=",self.current_phase)
    # def present_current_phase(self):
    #     return self.phases[self.current_phase].state
    def display(self):
        #print("Traffic Light Name:", self.id)
        return
    
